# AGENTS.override.md

## Project Objective

This repository is the GS-LSS research codebase and paper workspace.

Active paper:
- `writings/GS-LSS/bare_jrnl_new_sample4_revision.tex`

Review and revision inputs:
- `writings/reviews/tvcg_review_comments.md`
- `writings/reviews/revision_plan_1_major_revision.md`
- `writings/reviews/revision_plan_2_minimal_changes.md`
- `writings/GS-LSS/revision_sample/bare_jrnl_new_sample4_revision_text_revised.tex`

Current objective:
- Revise the GS-LSS TVCG paper based on the new review comments.
- Prefer the minimum-additional-experiment route unless a reviewer issue cannot be addressed honestly by text revision, claim weakening, existing outputs, or existing checkpoint-backed analyses.
- Preserve result integrity and keep every paper claim aligned with code, outputs, checkpoints, and verification scripts.

## Required Reading Order

Before substantial paper or experiment work, read:

1. Claude Code project history/memory for this repo, especially notes on paper revision, table provenance, failed runs, random batch, Table 3, floater figures, and checkpoint locations.
2. `writings/reviews/tvcg_review_comments.md`
3. `writings/reviews/revision_plan_2_minimal_changes.md`
4. `writings/reviews/revision_plan_1_major_revision.md`
5. `writings/GS-LSS/revision_sample/bare_jrnl_new_sample4_revision_text_revised.tex`
6. `writings/GS-LSS/bare_jrnl_new_sample4_revision.tex`
7. Active code paths: `run.sh`, `diag_run.sh`, `repro_develop3.sh`, `train_experimental_branch3_mc.py`, `train_experimental_branch3.py`, `scene_experimental_branch3/gaussian_model.py`, and `scene_experimental_branch3/imc_experimental.py`.

Use the sample revised TeX as a text-quality reference, not as automatically authoritative for all results.

## Revision Strategy

Default to the minimal-change revision plan.

- Downshift over-strong claims before adding experiments.
- Prefer “observed-support regularized stochastic optimization” over strict “scene-level distribution matching” or strict MCMC/Langevin claims.
- Present CPF as an observed-support estimator and regularizer, not as an unseen-geometry reconstructor.
- Clarify that CPF supervision is derived from biased 3DGS geometry and explain safeguards: global aggregation, DBSCAN filtering, normal/smoothness priors, delayed start, and observation-aware gating.
- Make LSS updates per-Gaussian and implementation-faithful. Avoid formulas that imply one global averaged perturbation applied to all Gaussians.
- Remove or demote random-view batch as a method contribution unless new fairness experiments explicitly support it.
- If random view batch is a fairness risk, prefer deleting random-batch descriptions and random-batch ablation over launching broad baseline reruns.
- Keep limitations visible and specific.

Do not defend fragile claims with vague prose. Either support them with provenance or weaken/remove them.

## Known High-Risk Areas

Audit these before finalizing the revision:

- Random batch: current `run.sh` uses `random_view_num=1` for most scenes and `3` only for `room`. Do not claim “batch size 3 in all experiments” unless proven for the exact reported results.
- Table 1 and Table 2: current Ours rows are backed by `experiments/paper_tables_update.py` using checkpoint-backed/per-metric selection. Preserve provenance when editing.
- Table 3: current checkpoint-backed local deliverables have previously been found lower than the paper’s MatrixCity/Zeche numbers. Audit before claiming these values as reproducible.
- LSS drift and variance: current fast config has `CPF_PULL_WEIGHT=0` and `CPF_NOISE_TRAIN_WEIGHT=0` by default. Do not overstate trained deterministic drift or trained variance-head behavior for the shipped fast recipe.
- Floater visualization: verify threshold, scene, checkpoint, and wording. Avoid “fewest consistently” unless backed across the displayed settings.
- Ablations and timing: captions and text must match exact dataset, split, checkpoint, and command.

## Experiment Policy

Run extra experiments only when needed to close a review issue that cannot be fixed by text, removing a claim, or reusing verified outputs.

Our method:
- Run on the local machine only.
- Use exactly one GPU: `CUDA_VISIBLE_DEVICES=1`.
- Save outputs under `/data1/zhangao/outputs`.
- Best checkpoints of our method are local under `/data1/zhangao/outputs`; use Claude history and provenance scripts to locate them.

Baselines:
- Run on `hust2` first.
- Use exactly one GPU on `hust2`: `CUDA_VISIBLE_DEVICES=3`.
- If `hust2` GPU 3 is unavailable, use local GPU 1 as fallback.
- Baseline checkpoints and outputs are under `/data1/zhangao/outputs` on `hust2`.

Environment:
- Use existing conda environments first.
- If the needed environment does not exist, create a conda environment and install packages with `pip`.
- Avoid unnecessary dependency upgrades that could invalidate earlier results.

Storage and transfer:
- Do not transfer large checkpoints or point clouds unless explicitly needed.
- If a large file is already on `hust2`, leave it there and acquire it only when required.
- Never delete previous outputs, checkpoints, logs, metrics, renders, or failed-run evidence unless explicitly asked.

Before any run:
- Check that the target output directory does not already exist, or choose a new descriptive directory.
- Record command, machine, GPU id, conda env, git state, dataset, split, scene, iterations, checkpoint, and output path.
- Prefer existing scripts and repo conventions over new infrastructure.

## Reporting Numbers

Never report a metric without:

- dataset and scene;
- biased-view protocol and split;
- method and important config;
- checkpoint or output path;
- metric script or command;
- whether the number is checkpoint-backed, metrics-only, or copied from paper text;
- whether it is best-PSNR run, per-metric best, mean over scenes, or mean over seeds.

For timing, also report:
- machine/GPU;
- iteration count;
- what is included or excluded;
- output path containing `training_time.txt` or timing JSON when available.

## Paper Editing Rules

- Edit the active paper unless the user asks for a copy: `writings/GS-LSS/bare_jrnl_new_sample4_revision.tex`.
- Keep a review-response mindset: every edit should map to a reviewer concern, plan item, or provenance fix.
- Preserve technical meaning when improving wording.
- Do not inflate claims to make tables look better.
- If a claim is no longer supported after removing random batch or weakening theory, rewrite the claim instead of hiding the issue.
- Prefer concise equations and pseudocode that match implementation.
- Compile the paper after nontrivial LaTeX edits and inspect warnings relevant to references, citations, figures, tables, and overfull boxes.

Useful verification scripts:
- `experiments/paper_tables_update.py`
- `experiments/stage2_deliverable.py`
- `experiments/stage3_deliverable.py`
- `experiments/verify_paper_tables.py`
- `experiments/verify_paper_tables2.py`

## Review Tracking

Maintain a simple issue map during revision:

- reviewer issue;
- action taken;
- file and line/section changed;
- evidence used;
- remaining risk.

If new experiments are run, add the command and result path to the issue map or final report.

## Safety

- Do not run destructive git commands.
- Do not overwrite or delete datasets, checkpoints, outputs, logs, or baseline results.
- Do not modify external repos on `hust2` unless needed for a baseline run and clearly recorded.
- Do not leave long-running experiments ambiguous; report where they run and how to monitor them.
- If commands need SSH, GPU access, package installation, or writes outside this repo, request/use escalation.

## Done Means

For paper revision work, report:
- edited files;
- review issues addressed;
- claims weakened, removed, or newly supported;
- compile/check commands and outcomes;
- unresolved risks.

For experiments, report:
- machine and GPU;
- exact command;
- conda env;
- dataset/scene/protocol;
- checkpoint/output path;
- metrics/runtime;
- failures and caveats.

For setup-only work, report:
- goal status;
- files changed;
- what the new instructions enforce.
