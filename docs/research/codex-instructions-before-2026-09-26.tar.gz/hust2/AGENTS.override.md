# AGENTS.override.md

## Current Paper Revision Objective

This repository is now in the TVCG revision stage for GS-LSS. The objective is
to revise the paper with the smallest scientifically honest set of changes that
can move the submission to acceptance.

Active paper:
- `writings/GS-LSS/bare_jrnl_new_sample4_revision_pro_v3.tex`

New review and revision inputs:
- `writings/new_reviews/TVCG_review_comments_GS-LSS.md`
- `writings/new_reviews/TVCG_acceptance_revision_plan_GS-LSS.md`
- `writings/new_reviews/GS_LSS_revised_acceptance_ready.tex`
- `writings/new_reviews/GS_LSS_revised_acceptance_ready.pdf`

Codex revision goal:
- Produce an acceptance-oriented revision of
  `writings/GS-LSS/bare_jrnl_new_sample4_revision_pro_v3.tex` from the v3
  manuscript baseline. Preserve the original main experiment tables and data,
  especially Table 1, Table 2, and Table 3. Focus the new main-text evidence on
  two strong supplemental blocks: (1) Bonsai free-space floater ratio (FFR), and
  (2) a merged LSS/component ablation table. Align wording with the TVCG review
  comments, revision plan, and sample revision, while keeping the compact
  Algorithm 1/method style from `bare_jrnl_new_sample4_revision_pro.tex`.
  Do not keep weak Truck FFR, weak split-location robustness, or noisy
  standalone component diagnostics in the main narrative. Fine-tune the selected
  supplemental evidence when needed; if a result remains weak, narrow the paper
  claim instead of overstating it.

## Non-Negotiable Revision Constraints

These constraints override any older notes, scripts, generated audits, or prior
Codex decisions.

- Do not modify the original main experiment data in the active paper. In
  particular, do not replace or shrink Table 1/Table 2/Table 3, do not remove
  methods from those tables, and do not change their reported metrics merely
  because local provenance is incomplete.
- Do not reduce the perceived strength of the main results by replacing broad
  original tables with narrower traceable subsets. Provenance repair is useful
  for internal confidence, but it is not a license to rewrite the main
  benchmark scope.
- Keep coverage gap, discontinuous trajectory, and angle disparity as co-equal
  main experimental protocols. Do not describe discontinuous trajectory or angle
  disparity as merely complementary or secondary evidence.
- In this v3 revision round, concentrate new main-text evidence on Bonsai FFR
  and a merged LSS/component ablation table. Address CPF circularity with concise
  evidence-faithful wording or provenance-backed diagnostics, but do not add a
  large standalone CPF reliability table unless it clearly improves the paper.
  Do not include weak split-location or Truck FFR tables in the main narrative.
- Table 4 / ablation material may be redesigned or replaced when needed to
  address the reviewer concern, but values must come from verified experiments,
  existing original-table data, or clearly documented generated evidence. Never
  fabricate or silently cherry-pick metrics.
- For any newly added experiment, the result must be strong enough to support
  the paper claim it is introduced for. If a new experiment is weak,
  inconsistent, or visually/quantitatively unconvincing, first fine-tune the
  relevant model and defensible hyperparameters until the result can provide
  positive evidence for the intended claim. Only after reasonable fine-tuning
  fails should the claim be narrowed, and the limitation must be reported
  clearly to the user before finalizing the paper.
- Use `writings/new_reviews/GS_LSS_revised_acceptance_ready.tex` as a wording
  and structure reference only. Do not copy its placeholder tables into the
  paper, and do not let it override the original paper's stronger main
  experiment data.
- If an original paragraph, claim flow, or table is not substantively criticized
  by the reviews and is not technically wrong, preserve it by default.
- The revision should be minimal but complete: add the missing evidence and fix
  risky wording without making the paper look like a different, weaker paper.

## Required Reading Order

Before substantial paper editing or experiment work, read:

1. `AGENTS.override.md`
2. `writings/new_reviews/TVCG_review_comments_GS-LSS.md`
3. `writings/new_reviews/TVCG_acceptance_revision_plan_GS-LSS.md`
4. `writings/new_reviews/GS_LSS_revised_acceptance_ready.tex`
5. `writings/GS-LSS/bare_jrnl_new_sample4_revision_pro_v3.tex`
6. Relevant local scripts, logs, figure outputs, and checkpoint provenance before
   using any metric or figure in the paper.

Use `GS_LSS_revised_acceptance_ready.tex` as a writing, wording, and structure
reference, not as authoritative evidence. It mainly demonstrates how the
revision can address reviewer concerns through targeted text edits, but this
round should not inherit its page-budget compression. Preserve the active
paper's original wording and paragraph logic by default when the original text
has no substantive problem. Adapt sample-draft phrasing only when it directly
fixes a reviewer concern, factual mismatch, unsupported claim, readability
problem, or implementation/evidence inconsistency.
Placeholders and proposed tables must still be filled only with verified results.

## Revision Strategy

Default to the minimum-change route, but do not undercut scientific validity.

- Prefer targeted text rewrites, table redesigns, and reuse of verified outputs
  before launching broad new sweeps.
- Run or fine-tune any necessary experiment when a reviewer issue cannot be
  answered honestly by text revision, claim weakening, existing outputs, or
  checkpoint-backed analysis.
- If a needed result does not match the planned claim, continue fine-tuning
  within a documented, scientifically defensible search space, or revise the
  claim/table so it matches the evidence.
- If an experiment is close but not yet strong enough to support an
  acceptance-critical claim, try a few targeted fine-tuning rounds before
  weakening the claim, provided the search is documented and uses reasonable
  hyperparameters rather than ad hoc cherry-picking.
- Newly added experiments have a higher bar than retrospective diagnostics:
  they should be fine-tuned until they provide clearly supportive evidence for
  the claim they are meant to prove, within a scientifically defensible search
  space.
- Never fabricate, smooth, or selectively hide inconvenient metrics. If a tradeoff
  remains, make the paper explain it cleanly and support the central claim with
  the right metric.
- Preserve the strongest acceptance narrative:
  GS-LSS is a CPF-guided observed-support stochastic optimizer that improves
  biased-view robustness by reducing support violations, not by hallucinating
  fully unseen geometry.
- Do not mention internal scene-omission or bookkeeping decisions in
  paper-facing text. In particular, do not explain any missing or unused
  Flowers discontinuous evidence in the paper or rebuttal unless the user
  explicitly asks for that disclosure. Use only the audited public protocol and
  table definitions.

## Hard Local Runtime Constraints

These constraints override older notes, stale scripts, and copied instructions.

- All local repositories are under `/data1/zhangao/repos`. Search that root
  before assuming a method repo is unavailable.
- All experiment outputs, metrics, logs, renders, and local checkpoints belong
  under `/data1/zhangao/outputs`. This root may already contain reusable
  checkpoints, so inspect it before launching replacement training. Do not
  place new paper evidence under ad hoc repo-local output directories unless a
  script requires a temporary path that is then copied or documented under
  `/data1/zhangao/outputs`.
- GS-LSS / our model must run in the `3dgs-imc` conda environment.
- Baselines and other papers' methods must use their corresponding
  method-specific conda environments. If a baseline environment is missing, a
  new conda environment may be created, but dependencies should be installed
  with `pip` inside that environment.
- CUDA jobs must use `CUDA_VISIBLE_DEVICES=2` unless the user explicitly changes
  the active GPU rule.
- Full checkpoints may exist on `ssh hust10`, but remote artifacts are not
  final paper evidence until copied locally or directly verified and documented.

## Acceptance-Critical Work

Treat the following as P0/P1 acceptance gates.

P0 method clarity:
- Rewrite the method around a per-primitive reparameterized stochastic update.
- Remove or demote exact MCMC, posterior sampling, and stationary-distribution
  claims.
- Make Eq. 18-style updates implementation-faithful: explicit sampled noise,
  CPF drift, learned/adaptive scale, gate/clamp behavior, and inference-time
  CPF removal.
- Add or preserve an Algorithm 1-style description that a reader can reproduce.

P0 observed-support evidence:
- Add CPF reliability diagnostics or verified alternatives that directly address
  whether CPF learns biased 3DGS floaters.
- Add a CPF-independent free-space floater metric, preferably opacity-weighted
  FFR against SfM/MVS or aggregated depth support.
- Define thresholds, regions, scenes, checkpoints, and scripts clearly.

P1 robustness and ablation:
- Add split robustness over multiple gap centers when feasible.
- Add component ablations for the acceptance-critical mechanisms: CPF drift,
  learned variance, observation-aware gate, DBSCAN/outlier filtering, normal
  loss, and color loss.
- Prefer a compact but decisive table over many weak tables.

P1 fairness and reproducibility:
- Clarify baseline configuration, Gaussian-count policy, split seeds, gap
  centers, image resolution, iterations, and hardware.
- Do not claim a baseline setting is "fair" unless the actual configuration and
  limitations are stated.

P2 presentation:
- Add limitations and failure cases that match the method boundary.
- Fix terminology, captions, typos, figure readability, metadata, and references.
- Replace small or confusing visualizations with paper-ready figures when needed.

## Table 4 / SSIM Risk Policy

The review explicitly flags Table IV/Table 4 because the full
`N(mu_theta, sigma_theta)` model has lower SSIM than the learned-variance-only
variant. This is a high-risk acceptance issue.

Do not handle this by vague prose. Use one of these evidence-backed strategies:

- Fine-tune the full model and ablation variants under the same protocol until
  the result is stable and the table reflects the method's intended behavior.
- Redesign Table 4 so it evaluates the theoretical claim directly. For example,
  include FFR or another support-consistency metric alongside PSNR/SSIM/LPIPS,
  so the full model can be justified by artifact reduction even if SSIM remains
  slightly lower.
- Split the current parameterization ablation from the component ablation if a
  single table becomes confusing.
- Do not frame the Table 4 issue as a weak trade-off narrative. If a metric or
  row weakens the central claim, either fine-tune the variants under the same
  protocol until the full GS-LSS configuration provides strong evidence, or
  redesign the table so it directly evaluates the intended mechanism with
  scientifically honest metrics such as support consistency and component
  necessity. Any non-dominant metric must be reported accurately, but the paper
  should not voluntarily recast the method contribution as a trade-off unless
  the user explicitly asks for that interpretation.
- Never write that the full model is best on all metrics unless the verified
  table actually shows it.
- Do not assume the previously generated two-scene Table 4 replacement is the
  default solution. Start from the original paper's ablation table and the
  reviewer's actual criticism. If Table 4 is changed, the change must preserve
  or strengthen the ablation narrative: either add a support-consistency metric
  such as FFR, add a compact component ablation, or replace the table with a
  clearly better evidence-backed version. Do not weaken the main paper by
  swapping in a narrower or less convincing table just because it is easier to
  audit.

Before finalizing Table 4, record:
- exact dataset, scene, split, gap setting, and random seed;
- exact variant definitions and config diffs;
- checkpoint/output path for every row;
- metric command and metric output file;
- whether values are final, fine-tuned, or copied from an older paper table.

## Efficiency Table Policy

The active training-time table should be preserved by default. Do not redesign,
replace, or numerically "repair" the existing efficiency table just because a
local mapped artifact differs from the raw paper value.

- Keep the previous time table unless the user explicitly asks to replace it.
- For the efficiency ablation/revision, first recover the original checkpoint,
  `command.txt`, `full_args.json`, timing file, and training parameters behind
  the existing rows. Treat these as the preferred provenance base. If additional
  improvement is needed, start from the same checkpoint/protocol or the closest
  matching one rather than introducing a new timing protocol.
- The likely source for the 38.76 min GS-LSS timing row has been found on
  `hust10`:
  `/data1/zhangao/outputs/ours_timing_diag/tandt/truck_resize_discontinuous_clean_shipped_i30000`
  reports 2325.79 s = 38.763 min and includes `command.txt` plus
  `full_args.json`. Its small provenance files are locally backed up under
  `/data1/zhangao/outputs/hust10_efficiency_timing_20260704/truck_resize_discontinuous_clean_shipped_i30000`.
  The 30K checkpoint PLY has now been fully backed up locally as
  `point_cloud/iteration_30000/point_cloud.ply` with size 496001532 bytes.
  A stale `point_cloud.ply.partial` file remains only as interrupted-transfer
  residue and should not be used as evidence.
- This timing candidate uses `truck_resize/discontinuous.txt`, while the active
  table uses 60-degree coverage-gap PSNR/SSIM values. Paper wording should keep
  these two quantities separated: quality comes from the 60-degree coverage-gap
  table, while time is the recorded 30K wall-clock used for the efficiency
  comparison. Do not present the timing candidate as strict coverage-gap timing
  unless an exact same-protocol timing artifact is found.
- The currently known local mismatch is GS-LSS: the active table reports
  38.76 min, while `/data1/zhangao/outputs/t7_bonsai/ours/wall_seconds.txt`
  records 2859.79 s = 47.663 min for a Bonsai 60 run. Treat that Bonsai run as
  useful provenance for a checkpoint/config, not as an automatic replacement for
  the table.
- Paper-facing wording should remain bounded: GS-LSS has moderate training
  overhead in the reported table, and CPF is removed at inference. Exact FPS or
  memory claims require traceable measured artifacts.

## Experiment Policy

Use existing project scripts and environments first. Do not overwrite prior
outputs.

Repository and artifact roots:
- Treat `/data1/zhangao/repos` as the local root for all method repositories.
  Search this root before assuming a required baseline or auxiliary repository
  is missing.
- Treat `/data1/zhangao/outputs` as the local root for all experiment outputs,
  metrics, renders, logs, and checkpoints. Search this root before launching a
  replacement run or declaring an artifact unavailable.
- Complete checkpoints may also exist on `ssh hust10`. Do not depend on remote
  checkpoints for a paper claim unless they have been copied locally or their
  provenance has been directly verified and documented.
- For discontinuous-trajectory experiments in this GS-LSS revision, the user has
  indicated that the relevant full checkpoints exist on `ssh hust10`. The
  default strategy is to import and verify those artifacts rather than
  reproduce the benchmark locally. Do not spend local GPU time rerunning the
  full discontinuous benchmark unless the remote checkpoints are confirmed
  unrecoverable or the final table decision requires a targeted replacement.
  After import, copy checkpoints/metrics/logs locally under
  `/data1/zhangao/outputs` and run only the missing render/metrics evaluation
  needed for traceable paper evidence.

All experiments:
- Run locally only. Do not launch experiments on remote hosts or external
  machines unless the user explicitly changes this rule.
- Use exactly one GPU: set `CUDA_VISIBLE_DEVICES=2` for training, fine-tuning,
  rendering, and evaluation commands that touch CUDA. Do not use other GPU ids
  unless the user explicitly changes this rule.
- GPU 2 may also contain unrelated work. Do not block, skip, or delay our
  documented experiments merely because another process is visible on GPU 2.
  Proceed with `CUDA_VISIBLE_DEVICES=2`; only react to concrete failures such as
  OOM, CUDA launch failure, corrupted output, or abnormal watchdog termination.
  When co-running may affect timing, record the co-tenancy caveat for runtime
  evidence, but do not let it stop quality/metric experiments.
- For GS-LSS / our model, use the `3dgs-imc` conda environment. Do not use
  `gsprior` for new GS-LSS training, rendering, evaluation, or fine-tuning
  unless the user explicitly changes the environment rule.
- For baselines or other papers' methods, use the corresponding method-specific
  conda environment for that repository/method when available. If a required
  baseline environment is missing and a new conda environment must be created,
  use conda only to create the environment shell, then install packages with
  `pip` inside that environment unless the user explicitly asks otherwise.
- Save outputs under `/data1/zhangao/outputs` using descriptive names. Treat
  this root as the first place to search for prior outputs, metrics, and
  checkpoints.

Baselines:
- Prefer existing baseline outputs and checkpoints when they are traceable.
- If new baseline runs are necessary, run them locally with
  `CUDA_VISIBLE_DEVICES=2` and record the exact command and output directory.
- Keep baseline configs and method versions explicit.

Before any run:
- Check whether the target output directory already exists; choose a new
  descriptive directory if needed.
- Record command, host, GPU id, conda env, git/worktree state if available,
  dataset, scene, split, gap center, seed, iterations, checkpoint, and output
  path.
- Prefer single-scene smoke tests before expensive sweeps.
- Monitor logs for divergence, stale checkpoints, wrong split files, and metric
  scripts using old outputs.
- For any long-running training, fine-tuning, rendering, or evaluation batch,
  start or attach exactly one background watchdog for the target run. The
  watchdog must monitor completion, interruption, abnormal termination, and a
  heartbeat, but Codex should then enter sleeper mode instead of repeatedly
  querying the process/GPU state. The sleeper should wake only on terminal
  watchdog states (`completed`, `interrupted`, or `abnormal`) or explicit user
  intervention; heartbeat updates are for diagnostics and should not trigger
  active polling. The default local tools are `scripts/watch_training_signal.py`
  and `scripts/sleep_until_watchdog_signal.sh`. For single-target component
  ablations, prefer `scripts/launch_component_ablation_watchdog.sh`, which
  launches the job, starts the single watchdog, waits on a fresh terminal
  signal, and returns a nonzero status for interrupted or abnormal completion.
  Record the watchdog signal and heartbeat paths in the experiment notes. Do
  not stack multiple watchdogs on the same training target; if a stale or broken
  watchdog exists, repair, replace, or explicitly supersede it before waiting.
  Prefer a real launcher-owned lifecycle signal, e.g.
  `--done-sentinel` and `--failed-sentinel`; when the launcher spawns a
  conda/Python child, also pass a real training child PID or a narrow
  `--process-pattern` tied to the output directory, so a stopped CUDA child is
  visible in the heartbeat. Do not rely only on `--process-pattern` across
  Codex sessions, because process visibility can be sandbox-dependent. A
  single-target watchdog wrapper around a batch launcher must pass the target
  `SCENES`, `CENTERS`, `SAVE_ITERATIONS`, and `EVAL_ITERATIONS` explicitly in
  the launcher command environment, must monitor the target model directory
  rather than a broad output root, and must require launcher-owned done/failed
  sentinels before reporting `completed`; otherwise a first completed center
  can wake Codex while the launcher silently continues to later centers.
  A done sentinel is not by itself completion evidence: if the launcher or
  target child is still alive and expected metrics are missing, continue
  monitoring instead of reporting `abnormal` or `completed`.
  A normal sandbox `ps` or `nvidia-smi` failure is not proof that the host CUDA
  process has stopped; when sandbox process/GPU visibility conflicts with a
  fresh heartbeat or user observation, confirm from the host/elevated view
  before declaring the run idle, stopped, or abnormal. A
  launcher exit with incomplete expected metrics
  must be treated as `abnormal`, not as still running. Clear or version the
  watchdog signal/heartbeat path before starting a new run, or wait with a
  start-time freshness guard, e.g.
  `scripts/sleep_until_watchdog_signal.sh SIGNAL 60 "$RUN_START_EPOCH"`, so a
  stale signal from a previous run cannot wake the session. When the only
  remaining action is waiting for training, do not merely leave a watchdog in
  the background. Keep the current Codex turn blocked on
  `scripts/launch_component_ablation_watchdog.sh` or a foreground
  `scripts/sleep_until_watchdog_signal.sh ...` command, so the session returns
  as soon as the watchdog writes `completed`, `interrupted`, or `abnormal`.
  The watchdog itself must write `interrupted` when it receives `SIGINT` or
  `SIGTERM`, and PID checks must treat zombie processes as exited rather than
  alive. Bash wrappers must not use bare `kill -0` as the only liveness test;
  after `kill -0` succeeds, inspect `/proc/<pid>/status` and treat `Z`/`X`
  states as exited. This prevents a stopped CUDA job from being mistaken for
  an active run. Terminal watchdog states must be mirrored to both
  `watchdog.signal.json` and `watchdog.heartbeat.json`; a final heartbeat that
  still says `running` after a completed/interrupted/abnormal signal is
  misleading and must be treated as a watchdog bug.
  If a GPU appears idle before an explicit wake message is observed, do not
  start manual polling loops. Read the newest `watchdog.signal.json` and
  `watchdog.heartbeat.json` once, then either re-enter sleeper mode or handle
  the terminal watchdog state.
  A watchdog is only a wakeup mechanism, not an experiment scheduler. After a
  `completed` signal, if acceptance-critical queued work remains and no
  parallel task blocks progress, immediately start the next documented run with
  a fresh output directory/watchdog, or explicitly report that the GPU is idle
  and why it is not being used.
  For hyperparameter sweeps with
  `scripts/launch_hyperparam_sensitivity_watchdog.sh`, do not leave the
  default multi-row `SPECS` queue running without an attached foreground wait.
  Prefer `MAX_RUNS=1` with an explicit single-row `SPECS='name|...'` command
  unless the current Codex turn will remain attached through every queued row.
  If a queued row is interrupted after a previous row completed, mark only that
  row as interrupted and never use its partial artifacts as paper evidence.

For fine-tuning:
- Fine-tuning is allowed and expected when needed to make necessary experiments
  reach the paper's intended claims.
- Do not assume the last training iteration is always the best checkpoint for
  large-gap or other weakly supervised protocols. The user has observed that
  20K checkpoints can outperform 30K checkpoints under large angular gaps,
  possibly because 30K overfits weakly observed regions. Treat this as a
  hypothesis to verify: for new GS-LSS supplementary experiments, save and
  evaluate both 20K and the final iteration when feasible, and document the
  checkpoint-selection rule before using the result in the paper.
- When results are unsatisfactory but plausibly recoverable, run several
  targeted fine-tuning rounds if GPU time permits, adjusting defensible
  hyperparameters and training length until the result either supports the
  intended paper argument or the remaining limitation is clear.
- For this GS-LSS revision only, scene-specific fine-tuning is allowed. Other
  papers/projects should still be treated as not allowing scene-specific
  fine-tuning unless the user explicitly grants it for that paper.
- Keep the search space defensible: learning rates, CPF/LSS start iteration,
  `lambda_s`, `eta_epsilon`, DBSCAN epsilon, gate/clamp behavior, training
  length, and `random_view_num` / random batch count are reasonable; ad hoc
  metric cherry-picking is not.
- Treat `random_view_num=3` as an unverified but allowed internal fine-tuning
  candidate for weak scenes. If it is used, record it in command/config
  provenance. Do not restore random-batch or random-view training as a paper
  contribution, claim, or ablation.
- Save each round under a distinct output directory and report the final chosen
  config plus enough failed/partial attempts to make the result reproducible.

## Reporting Numbers

Never report a number without:

- dataset and scene;
- biased-view protocol, split, gap size/center, and seed;
- method and config;
- checkpoint or output path;
- metric script or command;
- whether the number is checkpoint-backed, metrics-only, copied from a previous
  table, or newly generated;
- whether it is a single run, best checkpoint, per-metric best, mean over scenes,
  or mean over seeds.

For FFR or geometry metrics, also report:
- reference support source, e.g. SfM/MVS/aggregated depth;
- distance threshold;
- region definition, e.g. held-out gap sector;
- opacity weighting and filtering rules.
- If using a favorable or representative scene for FFR ablation, state the
  selection rationale before interpreting the result, e.g. visible severe
  floaters, complete artifact coverage, and direct connection to an existing
  figure. Frame it as a scene-level diagnostic or case study, not as
  cross-scene evidence. Do not hide or contradict broader audits when making
  general claims.

For timing, also report:
- host/GPU;
- iteration count;
- what is included/excluded;
- output path containing timing evidence.

## Paper Editing Rules

- Edit the active paper:
  `writings/GS-LSS/bare_jrnl_new_sample4_revision_pro_v3.tex`.
- This revision does not enforce a main-paper page limit. Prefer a readable
  main-paper revision that directly explains each necessary experiment,
  diagnostic, and limitation over a compressed 12-page version. New evidence may
  remain in the main paper when it improves reviewer-response clarity, while
  purely procedural provenance can still be placed in supplementary material.
- Keep every edit tied to a reviewer concern, revision-plan item, or provenance
  correction.
- Do not perform broad stylistic rewriting. If the original description is
  technically correct, evidence-faithful, and not challenged by a review point,
  keep it as-is.
- Preserve the user's technical intent while making claims more precise and
  defensible.
- Do not inflate claims to make a table look better.
- Remove or weaken claims that are not supported after experiments.
- Avoid final placeholders such as `\todoentry`, "should be filled", or
  unverified table rows.
- Compile the paper after nontrivial LaTeX edits and inspect warnings relevant
  to references, citations, floats, missing figures, tables, and overfull boxes.
- After compilation, record the PDF page count for awareness only. Do not reduce
  or move content solely because the PDF exceeds 12 pages in this revision.

Maintain a revision issue map during the work, preferably in
`writings/new_reviews/`, containing:

- reviewer issue;
- action taken;
- paper section/table/figure changed;
- evidence source;
- remaining risk.

## Known High-Risk Areas

Audit these before finalizing:

- CPF circularity: supervision comes from biased 3DGS-derived geometry, so the
  paper needs reliability diagnostics and careful wording.
- MCMC/Langevin language: keep the method framed as stochastic optimization.
- Table 4: SSIM risk and component-ablation strength.
- Geometry claims: support with FFR/CPF reliability or weaken.
- Split randomness: distinguish training stochasticity from gap-location
  robustness.
- Baseline fairness: avoid overclaiming official/default/tuned comparisons.
- Training-view batching: treat it only as a recorded implementation
  configuration; do not present it as a contribution, paper claim, or ablation.
- Figures: ensure all paper figures are legible, ordered, and directly useful
  for the acceptance narrative.
- Readability budget: previous 12-page compression made parts of the paper hard
  to read. Do not remove important context, explanations, or diagnostic tables
  solely to reduce length in this revision.

## Safety

- Do not run destructive git commands.
- Do not overwrite or delete datasets, checkpoints, logs, metrics, renders, or
  failed-run evidence unless explicitly asked.
- Do not modify external repositories or remote baseline setups without a clear
  need and recorded command.
- Do not leave long-running experiments ambiguous; report where they run and how
  to monitor them.
- If commands need SSH, GPU access, package installation, or writes outside this
  repo, request/use escalation.

## Done Means

For setup/instruction work:
- `AGENTS.override.md` points to the new active paper and review inputs;
- the Codex revision goal is explicit;
- acceptance-critical risks and experiment policies are encoded.

For paper revision work:
- edited files are listed;
- review issues addressed are mapped to changes;
- claims weakened, removed, or newly supported are stated;
- compile/check commands and outcomes are reported;
- unresolved risks are explicit.

For experiments:
- host/GPU, command, env, dataset/scene/protocol, checkpoint/output path,
  metrics/runtime, failures, and caveats are reported.
